/*========== menu icon navbar ==========*/
let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');


/*========== scroll sections active link ==========*/
let sections = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');

window.onscroll = () => {


    /*========== sticky navbar ==========*/


    /*========== remove menu icon navbar when click navbar link (scroll) ==========*/

};


/*========== swiper ==========*/


/*========== dark light mode ==========*/


/*========== scroll reveal ==========*/